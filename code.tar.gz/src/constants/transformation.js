const TRANSFORMATION_TYPES = [
  { title: 'to upper case', value: 'TO_UPPER_CASE' },
  { title: 'to lower case', value: 'TO_LOWER_CASE' },
];

module.exports = { TRANSFORMATION_TYPES };
